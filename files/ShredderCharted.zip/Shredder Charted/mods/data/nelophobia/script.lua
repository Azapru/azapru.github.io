function onStartCountdown()
setProperty('health', 2)
end

function onUpdate(elapsed)
songPos = getSongPosition()
local currentBeat = (songPos/1000)*(curBpm/60)
local currentBeat2 = (songPos/1000)*(curBpm/60)*2
noteTweenY('defaultPlayerStrumY0', 4, ((screenHeight / 1.15) - (157 / 2)) + (math.cos((currentBeat) + 0) * 50), 0.01)
noteTweenY('defaultPlayerStrumY1', 5, ((screenHeight / 1.15) - (157 / 2)) + (math.cos((currentBeat) + 1) * 50), 0.01)
noteTweenY('defaultPlayerStrumY2', 6, ((screenHeight / 1.15) - (157 / 2)) + (math.cos((currentBeat) + 2) * 50), 0.01)
noteTweenY('defaultPlayerStrumY3', 7, ((screenHeight / 1.15) - (157 / 2)) + (math.cos((currentBeat) + 3) * 50), 0.01)
noteTweenY('defaultFPlayerStrumY0', 0, ((screenHeight / 1.3) - (157 / 2)) + (math.cos((currentBeat) + (4) * 2) * 100), 0.01)
noteTweenY('defaultFPlayerStrumY1', 1, ((screenHeight / 1.3) - (157 / 2)) + (math.cos((currentBeat) + (5) * 2) * 100), 0.01)
noteTweenY('defaultFPlayerStrumY2', 2, ((screenHeight / 1.3) - (157 / 2)) + (math.cos((currentBeat) + (6) * 2) * 100), 0.01)
noteTweenY('defaultFPlayerStrumY3', 3, ((screenHeight / 1.3) - (157 / 2)) + (math.cos((currentBeat) + (7) * 2) * 100), 0.01)
noteTweenX('defaultFPlayerStrumX0', 0, ((screenWidth / 4) - (157 / 2)) + (math.cos((currentBeat2) + (4) * 2) * 200), 0.01)
noteTweenX('defaultFPlayerStrumX1', 1, ((screenWidth / 4) - (157 / 2)) + (math.cos((currentBeat2) + (5) * 2) * 200), 0.01)
noteTweenX('defaultFPlayerStrumX2', 2, ((screenWidth / 4) - (157 / 2)) + (math.cos((currentBeat2) + (6) * 2) * 200), 0.01)
noteTweenX('defaultFPlayerStrumX3', 3, ((screenWidth / 4) - (157 / 2)) + (math.cos((currentBeat2) + (7) * 2) * 200), 0.01)
function opponentNoteHit(id, direction, noteType, isSustainNote)
cameraShake(game, 0.015, 0.2)
cameraSetTarget('dad')
characterPlayAnim('gf', 'scared', true)
doTweenZoom('camerazoom','camGame',1.1,0.2,'quadInOut')
setProperty('health', getProperty('health') - 0.5 * ((getProperty('health')/22))/6)
end
function goodNoteHit(id, direction, noteType, isSustainNote)
cameraSetTarget('boyfriend')
end
end